///
/// app.js
///

import React, { Component } from 'react'
import { observer } from 'mobx-react'

@observer export class App extends Component {

	///
	OnChangeUserName = (e) => {

		// Extract value from the event object.
		const NewValue = e.target.value;
		
		// Update the model *directly* using a model method.
		this.props.model.SetUserName(NewValue);

	}

	///
	OnChangeUserAge = (e) => {

		// Extract value from the event object.
		const NewValue = e.target.value;
		
		// Update the model *directly* using a model method.
		this.props.model.SetUserAge(NewValue);

	}

	///
	render() {

		// Sample the current state.  Notice we use methods on the model to preserve encapsulation.
		const UserName = this.props.model.UserName();
		const UserAge = this.props.model.UserAge();

		return (

			<main>

				<div className="x-centered-y-centered-column">

					<h3>User name</h3>
					<input type="text" name="UserName" onChange={this.OnChangeUserName} />
					<h3>Age</h3>
					<input type="text" name="UserAge" onChange={this.OnChangeUserAge} />

				</div>

				<div style={{ marginTop:3 + "rem" }}>

					User Name: {UserName}<br/>
					Age: {UserAge}<br/>

				</div>

			</main>

		);

	}

}
