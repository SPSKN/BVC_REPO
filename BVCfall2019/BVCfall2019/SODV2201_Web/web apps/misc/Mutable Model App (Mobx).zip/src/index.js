///
/// index.js
///

import 'normalize.css';
import 'sanitize.css';
import './brandize.css';
import React from 'react';
import ReactDOM from 'react-dom';
import { App } from './app.js';
import { Model } from './model.js'

///
/// Render the appropriate component into the DOM starting at the #root <div> in index.html.
///
ReactDOM.render(<App model={Model} />, document.getElementById('root'));
