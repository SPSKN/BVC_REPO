///
/// An independent model representing the application under a mutable state design.
///

import { observable } from 'mobx';

export const Model = observable({

	User:{ 
		Name:"", 
		Age:0 
	}

});

///
Model.Reset = function() {

	// Reset the model.
	this.User.Name = "";
	this.User.Age = 0;

}

///
Model.SetUserName = function(newvalue) {
	this.User.Name = newvalue;
}

///
Model.SetUserAge = function(newvalue) {
	this.User.Age = newvalue;
}

///
Model.UserName = function() {
	return(this.User.Name);
}

///
Model.UserAge = function() {
	return(this.User.Age);
}
