///
/// SplashPage
///

import React, { Component } from 'react'

export class SplashPage extends Component {

	///
	render() {

		return (

			<div>
				<header>
					<h1>Raterator V2!</h1>
				</header>
				
				
				<div class='centerContent'>Now loading...</div>
				
			</div>

		);

	}

}
