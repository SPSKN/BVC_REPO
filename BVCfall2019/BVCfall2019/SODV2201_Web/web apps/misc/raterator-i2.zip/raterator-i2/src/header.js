import React, { Component } from 'react';

export class HeadClass extends Component
{
     render(){


        return(

            <div>
                <span class='main-header'>
                    <h3 class='hamburger'>H</h3>
                    <h1 class='centerContent'>L</h1>
                </span>
            </div>
        );
     }


}
