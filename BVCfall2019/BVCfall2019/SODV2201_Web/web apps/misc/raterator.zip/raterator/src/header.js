import React, { Component } from 'react';

export class HeadClass extends Component
{
     render(){


        return(

            <div>
                <header>
                <h3>Hamburger</h3>
                <h1>LOGO</h1>
                </header>
            </div>
        );
     }


}
