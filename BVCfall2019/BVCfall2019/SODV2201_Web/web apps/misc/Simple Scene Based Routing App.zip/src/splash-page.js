///
/// SplashPage
///

import React, { Component } from 'react'

export class SplashPage extends Component {

	///
	render() {

		return (

			<div>

				<h1>Welcome to the simple routing app!</h1>

				<div>Now loading...</div>

			</div>

		);

	}

}
