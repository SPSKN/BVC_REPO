﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeTime
{
    public class CoffeeClass
    {
        public string cupSize{get;set;}
        public string MilkCount { get; set; }
        public string CreamCount { get; set; }
        public string SugarCount { get; set; }
        public bool WhipcreamTopping { get; set; }
    }
}
