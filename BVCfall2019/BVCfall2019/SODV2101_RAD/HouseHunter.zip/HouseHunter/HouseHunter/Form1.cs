﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HouseHunter
{
    public partial class Form1 : Form
    {/*
        public Form1()
        {
            InitializeComponent();
        }

        private void THouseBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tHouseBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.database1DataSet);

        }

        private void HouseHunter_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database1DataSet.THouse' table. You can move, or remove it, as needed.
            this.tHouseTableAdapter.Fill(this.database1DataSet.THouse);
            // TODO: This line of code loads data into the 'database1DataSet.THouse' table. You can move, or remove it, as needed.
            this.tHouseTableAdapter.Fill(this.database1DataSet.THouse);

        }

        private void THouseBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.tHouseBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.database1DataSet);

        }

        private void THouseDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        */
    }
}
