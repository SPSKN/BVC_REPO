﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graphs2
{
    class InputClass
    {
       
            public int input;

            public InputClass(string x)
            {
                input = Int32.Parse(x);
            }
        
    }
}
