package com.company;

/**
 * Assignment 1 - Using Data Structures
 * List
 * Stacks
 * Queue
 *
 * Course code : SODV2401
 * TERM/Year : winter2020
 * Assignment code: A1
 * Author : Scott Patterson
 * BVC username : s.patterson528@mybvc.ca
 * Date created : 2020-02-27
 * Description:
 *
 */
public class Main {

    public static void main(String[] args) {
	// write your code here
    Employee e = new Employee("scott",26449712,26,'m',"123 Fake Street","555 1123");

    System.out.println(e.name);
    e.addToDepartment();




    }

}
